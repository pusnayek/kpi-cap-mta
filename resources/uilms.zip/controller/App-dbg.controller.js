sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ui.lms.controller.App", {
        onInit() {
        }
      });
    }
  );
  